/*
  Warnings:

  - You are about to drop the column `user_id` on the `user_info` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "user_info" DROP COLUMN "user_id";
